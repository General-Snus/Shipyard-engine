#!/bin/bash

./external/premake/linux64/premake5_aarch64 gmake2
