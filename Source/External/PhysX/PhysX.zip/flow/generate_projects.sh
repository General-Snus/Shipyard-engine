#!/bin/bash

./external/premake/linux64/premake5 gmake2
